# Predeployed IMA

The package is a tool for generating configs for predeployed IMA